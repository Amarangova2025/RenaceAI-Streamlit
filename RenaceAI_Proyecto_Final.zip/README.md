# Renace AI 💖

Renace AI es una app emocional basada en IA que detecta emociones en frases y responde con empatía.

## Archivos requeridos:
- app.py
- modelo_entrenado.pkl
- vectorizer.pkl

## Uso local:
1. Instala Streamlit y joblib: `pip install streamlit joblib`
2. Ejecuta la app: `streamlit run app.py`

## Demo:
https://renaceai-app.streamlit.app/

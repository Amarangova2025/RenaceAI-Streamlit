
import streamlit as st
import joblib
import pandas as pd

# Cargar modelo y vectorizador
modelo = joblib.load("modelo_entrenado.pkl")
vectorizer = joblib.load("vectorizer.pkl")

# Diccionario de respuestas empáticas
respuestas = {
    "ansiedad": "Respira profundamente. Todo estará bien. 🌿",
    "culpa": "Recuerda que mereces perdonarte. 💖",
    "confusion": "Detente, respira y date permiso para no tener todas las respuestas. 🌫️",
    "tristeza": "Tu llanto es válido. Estoy aquí para acompañarte. 🌧️"
}

# Estilo de la app
st.set_page_config(page_title="Renace AI - Asistente Emocional", layout="centered")

st.title("💬 Renace AI - Asistente Emocional")
st.write("Escribe lo que estás sintiendo y pulsa Enter:")

# Historial de conversación
if "mensajes" not in st.session_state:
    st.session_state.mensajes = []

entrada_usuario = st.text_input("")

if entrada_usuario:
    st.session_state.mensajes.append(("👩", entrada_usuario))

    # Clasificación emocional
    vector = vectorizer.transform([entrada_usuario])
    emocion = modelo.predict(vector)[0]
    respuesta = respuestas.get(emocion, "Estoy contigo en este momento. ❤️")

    st.session_state.mensajes.append(("🤖 Renace AI", f"Emoción detectada → {emocion.capitalize()}
{respuesta}"))

# Mostrar conversación
for autor, texto in st.session_state.mensajes:
    st.markdown(f"**{autor}:** {texto}")
